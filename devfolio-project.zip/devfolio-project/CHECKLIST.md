# Assignment completion checklist

This starter covers a subset of the required project. Before submitting, work through every unchecked item.

- [ ] Finish serializers and validations for all required model fields, including upload size/type checks and publish transition rules.
- [ ] Implement reliable absolute media URLs for every uploaded image/file and verify with React.
- [ ] Finish API pagination sizes (posts 6, projects 9, comments/messages 10), filter names, and ordering fields exactly as assignment specifies.
- [ ] Implement related posts, complete post metadata, nested comments and visitor-specific `is_liked` in list/detail responses.
- [ ] Implement owner moderation endpoints, contact read/delete flows, category protection errors, and complete dashboard monthly aggregation.
- [ ] Implement a working refresh-token retry interceptor, logout blacklist flow, owner auth context and protected dashboard routes.
- [ ] Finish full CRUD forms for posts, projects, skills, experience, education, profile, categories and tags.
- [ ] Add upload previews, confirm-delete modal, inline API errors, toast feedback and all list loading/empty/error states.
- [ ] Add proper URL-synced debounced filters, pagination controls, responsive hamburger menu and SEO metadata.
- [ ] Add model-specific Django admin list display/search/filter and at least one signal.
- [ ] Export Postman collection; add automated permission/validation tests; run all acceptance tests.
- [ ] Add your own real portfolio content: profile, 10+ skills, 2+ education/experience entries, 3+ projects, 5+ original posts (4 published, 1 draft), 3 categories, 6 tags and moderation examples.
- [ ] Create two public GitHub repos with meaningful commits, link both READMEs, deploy if possible, record the 4–6 minute demo and submit links/credentials safely.
