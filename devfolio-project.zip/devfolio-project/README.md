# DevFolio — Portfolio + Blog

A full-stack portfolio starter based on the supplied assignment: Django REST Framework API and React + Vite frontend.

## Features currently included
- Django models for profile, skills, experience, education, projects, categories, tags, posts, likes, comments, and contact messages.
- JWT owner login, owner-only writes, profile singleton API, dashboard stats API, post like toggle, comment submission/moderation data, contact endpoint.
- Search/filter/order backends, request timing middleware, view cooldown, anonymous/contact/comment/like throttling configuration.
- React responsive portfolio pages, theme toggle, project/blog lists and details, contact form, like/comment controls, login page and dashboard overview.

> This is a project starter, not a claim that every acceptance criterion in the assignment is finished. Review `CHECKLIST.md`, test locally, and complete remaining requirements before submission. Content must be your own real information.

## Backend setup
```bash
cd backend
python -m venv venv
# Windows:
venv\Scripts\activate
# macOS/Linux: source venv/bin/activate
pip install -r requirements.txt
# Copy .env.example to .env and change SECRET_KEY / allowed origins
python manage.py makemigrations portfolio
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```
API base: `http://127.0.0.1:8000/api/`; Django admin: `http://127.0.0.1:8000/admin/`.

## Frontend setup
```bash
cd frontend
npm install
# Copy .env.example to .env
npm run dev
```
Set `VITE_API_URL=http://127.0.0.1:8000/api` in frontend `.env`.

## Authentication
There is no registration API. Create the site owner with `createsuperuser`. Login is available only at `/login`. API write permissions must always be enforced on the backend.

## Security and content
- Never commit `.env`, SQLite database, media uploads, virtualenv, `node_modules`, or production secrets.
- Set `DEBUG=False`, `ALLOWED_HOSTS`, and a strict `CORS_ALLOWED_ORIGINS` for deployment.
- Add your actual profile, photo, CV, social links, projects, and original blog posts before presenting the site.
- Validate upload size/type, complete API tests, and verify all permissions before public deployment.

## Repositories
When you create separate public repositories, add the backend repo URL here and the frontend repo URL to the frontend README (or link both from each README).
