from django.contrib import admin
from .models import *
for model in [Profile,Skill,Experience,Education,Project,Category,Tag,Post,PostLike,Comment,ContactMessage]:
 admin.site.register(model)
