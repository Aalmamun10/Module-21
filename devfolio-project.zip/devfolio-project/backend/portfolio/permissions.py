from rest_framework.permissions import SAFE_METHODS, BasePermission
class IsOwnerOrReadOnly(BasePermission):
    def has_permission(self, request, view):
        if request.method in SAFE_METHODS: return True
        return bool(request.user and request.user.is_authenticated and request.user.is_superuser)


class ContactPermission(BasePermission):
    """Anyone may submit a contact message; only the superuser may manage inbox items."""
    def has_permission(self, request, view):
        if request.method == 'POST': return True
        if request.method in SAFE_METHODS:
            return bool(request.user and request.user.is_authenticated and request.user.is_superuser)
        return bool(request.user and request.user.is_authenticated and request.user.is_superuser)
