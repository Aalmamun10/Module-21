from rest_framework import serializers
from django.utils import timezone
from .models import *

class AbsoluteURLMixin:
    def to_representation(self, instance):
        data=super().to_representation(instance)
        request=self.context.get('request')
        for field in ('avatar','resume','cover_image'):
            value=data.get(field)
            if value and request and not str(value).startswith('http'): data[field]=request.build_absolute_uri(value)
        return data

class ProfileSerializer(AbsoluteURLMixin,serializers.ModelSerializer):
    class Meta: model=Profile; fields='__all__'; read_only_fields=['created_at','updated_at']
class SkillSerializer(serializers.ModelSerializer):
    class Meta: model=Skill; fields='__all__'
    def validate_proficiency(self,v):
        if not 1<=v<=100: raise serializers.ValidationError('Proficiency must be between 1 and 100.')
        return v
class ExperienceSerializer(serializers.ModelSerializer):
    class Meta: model=Experience; fields='__all__'
    def validate(self,data):
        start=data.get('start_date',getattr(self.instance,'start_date',None)); end=data.get('end_date',getattr(self.instance,'end_date',None)); current=data.get('is_current',getattr(self.instance,'is_current',False))
        if start and start>timezone.localdate(): raise serializers.ValidationError({'start_date':'Start date cannot be in the future.'})
        if current and end: raise serializers.ValidationError({'end_date':'End date must be empty for a current role.'})
        if not current and (not end or (start and end<=start)): raise serializers.ValidationError({'end_date':'End date must be after start date.'})
        return data
class EducationSerializer(serializers.ModelSerializer):
    class Meta: model=Education; fields='__all__'
class ProjectSerializer(AbsoluteURLMixin,serializers.ModelSerializer):
    tech_stack=serializers.PrimaryKeyRelatedField(many=True,queryset=Skill.objects.all(),required=False)
    class Meta: model=Project; fields='__all__'
    def validate(self,data):
        live=data.get('live_url',getattr(self.instance,'live_url','')); github=data.get('github_url',getattr(self.instance,'github_url',''))
        if not live and not github: raise serializers.ValidationError('At least one of live_url or github_url is required.')
        return data
class CategorySerializer(serializers.ModelSerializer):
    posts_count=serializers.SerializerMethodField()
    class Meta: model=Category; fields='__all__'
    def get_posts_count(self,obj): return obj.posts.filter(status='PUBLISHED').count()
class TagSerializer(serializers.ModelSerializer):
    posts_count=serializers.SerializerMethodField()
    class Meta: model=Tag; fields='__all__'
    def get_posts_count(self,obj): return obj.posts.filter(status='PUBLISHED').count()
class PostSerializer(AbsoluteURLMixin,serializers.ModelSerializer):
    category=serializers.PrimaryKeyRelatedField(queryset=Category.objects.all())
    tags=serializers.PrimaryKeyRelatedField(queryset=Tag.objects.all(),many=True,required=False)
    category_name=serializers.CharField(source='category.name',read_only=True)
    likes_count=serializers.IntegerField(source='likes.count',read_only=True)
    comments_count=serializers.SerializerMethodField()
    class Meta: model=Post; fields='__all__'; read_only_fields=['author','published_at','views_count','reading_time','created_at','updated_at']
    def validate_title(self,value):
        if len(value.strip())<5: raise serializers.ValidationError('Title must contain at least 5 characters.')
        return value
    def validate(self,data):
        status_value=data.get('status',getattr(self.instance,'status','DRAFT'))
        content=data.get('content',getattr(self.instance,'content',''))
        category=data.get('category',getattr(self.instance,'category',None))
        if status_value=='PUBLISHED' and len(content)<100: raise serializers.ValidationError({'content':'Published posts must contain at least 100 characters.'})
        if status_value=='PUBLISHED' and not category: raise serializers.ValidationError({'category':'A category is required to publish a post.'})
        return data
    def get_comments_count(self,obj): return obj.comments.filter(is_approved=True).count()
class CommentSerializer(serializers.ModelSerializer):
    class Meta: model=Comment; fields=['id','post','name','email','website','content','parent','is_approved','created_at']; read_only_fields=['is_approved','created_at']
    def validate_name(self,v):
        if len(v.strip())<2: raise serializers.ValidationError('Name must contain at least 2 characters.')
        return v
    def validate_content(self,v):
        if not 5<=len(v)<=1000: raise serializers.ValidationError('Comment must contain 5–1000 characters.')
        return v
    def validate_parent(self,v):
        if v and v.parent_id: raise serializers.ValidationError('Replies can only be one level deep.')
        return v
class ContactMessageSerializer(serializers.ModelSerializer):
    class Meta: model=ContactMessage; fields='__all__'; read_only_fields=['is_read','created_at']
    def validate_message(self,v):
        if not 10<=len(v)<=2000: raise serializers.ValidationError('Message must contain 10–2000 characters.')
        return v
