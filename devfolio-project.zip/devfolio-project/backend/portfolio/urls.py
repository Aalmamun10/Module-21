from rest_framework.routers import DefaultRouter
from django.urls import path, include
from .views import *
router=DefaultRouter()
router.register('skills',SkillViewSet,basename='skill')
router.register('experiences',ExperienceViewSet,basename='experience')
router.register('education',EducationViewSet,basename='education')
router.register('projects',ProjectViewSet,basename='project')
router.register('categories',CategoryViewSet,basename='category')
router.register('tags',TagViewSet,basename='tag')
router.register('posts',PostViewSet,basename='post')
router.register('contact',ContactViewSet,basename='contact')
router.register('comments',CommentViewSet,basename='comment')
urlpatterns=[path('profile/',ProfileSingletonView.as_view()),path('',include(router.urls)),path('dashboard/stats/',DashboardStatsView.as_view())]
