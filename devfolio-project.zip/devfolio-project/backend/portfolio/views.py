from django.contrib.auth import authenticate
from django.core.cache import cache
from django.db.models import F, Count, Sum
from django.utils import timezone
from datetime import timedelta
from rest_framework import viewsets, status, filters
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.decorators import action
from rest_framework.throttling import AnonRateThrottle, ScopedRateThrottle
from rest_framework_simplejwt.tokens import RefreshToken, TokenError
from .models import *
from .serializers import *
from .permissions import IsOwnerOrReadOnly, ContactPermission

class LoginView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [AnonRateThrottle]
    def post(self, request):
        user = authenticate(request, username=request.data.get('username'), password=request.data.get('password'))
        if not user or not user.is_superuser:
            return Response({'detail': 'Invalid username or password.'}, status=401)
        refresh = RefreshToken.for_user(user)
        return Response({'refresh': str(refresh), 'access': str(refresh.access_token), 'user': {'id': user.id, 'username': user.username, 'email': user.email}})

class LogoutView(APIView):
    permission_classes = [IsAuthenticated]
    def post(self, request):
        try:
            RefreshToken(request.data.get('refresh')).blacklist()
        except (TokenError, AttributeError):
            return Response({'detail': 'Invalid refresh token.'}, status=400)
        return Response(status=204)

class MeView(APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request):
        if not request.user.is_superuser:
            return Response({'detail': 'Forbidden'}, status=403)
        return Response({'id': request.user.id, 'username': request.user.username, 'email': request.user.email})

class ChangePasswordView(APIView):
    permission_classes = [IsAuthenticated]
    def post(self, request):
        user = request.user
        if not user.is_superuser: return Response({'detail':'Forbidden'}, status=403)
        if not user.check_password(request.data.get('old_password', '')):
            return Response({'old_password':['Current password is incorrect.']}, status=400)
        new_password = request.data.get('new_password', '')
        if len(new_password) < 8: return Response({'new_password':['Use at least 8 characters.']}, status=400)
        user.set_password(new_password); user.save(update_fields=['password'])
        return Response({'detail':'Password changed. Please log in again.'})

class OwnerWriteViewSet(viewsets.ModelViewSet):
    permission_classes = [IsOwnerOrReadOnly]

class ProfileViewSet(OwnerWriteViewSet):
    queryset = Profile.objects.all(); serializer_class = ProfileSerializer
    def list(self, request, *args, **kwargs):
        obj = Profile.objects.first()
        return Response(self.get_serializer(obj, context={'request':request}).data if obj else {})
    def get_object(self):
        obj = Profile.objects.first()
        if obj is None:
            from rest_framework.exceptions import NotFound
            raise NotFound('Profile has not been created yet.')
        return obj

class ProfileSingletonView(APIView):
    permission_classes=[IsOwnerOrReadOnly]
    def get(self,request):
        obj=Profile.objects.first()
        return Response(ProfileSerializer(obj,context={'request':request}).data if obj else {})
    def patch(self,request):
        obj=Profile.objects.first()
        serializer=ProfileSerializer(obj,data=request.data,partial=True,context={'request':request}) if obj else ProfileSerializer(data=request.data,context={'request':request})
        serializer.is_valid(raise_exception=True); serializer.save()
        return Response(serializer.data)

class SkillViewSet(OwnerWriteViewSet):
    queryset=Skill.objects.all(); serializer_class=SkillSerializer
    filterset_fields=['category','is_featured']; search_fields=['name']; ordering_fields=['display_order','proficiency']; ordering=['display_order']
class ExperienceViewSet(OwnerWriteViewSet):
    queryset=Experience.objects.all(); serializer_class=ExperienceSerializer; ordering=['-start_date']
class EducationViewSet(OwnerWriteViewSet): queryset=Education.objects.all(); serializer_class=EducationSerializer
class ProjectViewSet(OwnerWriteViewSet):
    queryset=Project.objects.prefetch_related('tech_stack').all(); serializer_class=ProjectSerializer; lookup_field='slug'
    filterset_fields=['category','is_featured']; search_fields=['title','summary','description']; ordering_fields=['completed_date','display_order']; ordering=['display_order']
    pagination_class = None

class CategoryViewSet(OwnerWriteViewSet): queryset=Category.objects.all(); serializer_class=CategorySerializer
class TagViewSet(OwnerWriteViewSet): queryset=Tag.objects.all(); serializer_class=TagSerializer

class PostViewSet(OwnerWriteViewSet):
    queryset=Post.objects.select_related('category','author').prefetch_related('tags','likes').all(); serializer_class=PostSerializer; lookup_field='slug'
    filterset_fields=['category__slug','tags__slug','is_featured','status']; search_fields=['title','excerpt','content']; ordering_fields=['published_at','views_count','title']; ordering=['-published_at']
    def get_queryset(self):
        qs=super().get_queryset()
        if not (self.request.user.is_authenticated and self.request.user.is_superuser): qs=qs.filter(status='PUBLISHED')
        return qs
    def perform_create(self,serializer): serializer.save(author=self.request.user)
    def retrieve(self,request,*args,**kwargs):
        obj=self.get_object(); visitor=request.headers.get('X-Visitor-Id')
        if visitor:
            key=f'post-view:{obj.pk}:{visitor}'
            if not cache.get(key):
                Post.objects.filter(pk=obj.pk).update(views_count=F('views_count')+1); cache.set(key,True,timeout=1800); obj.refresh_from_db()
        data=self.get_serializer(obj).data
        data['likes_count']=obj.likes.count()
        data['is_liked']=bool(visitor and obj.likes.filter(visitor_id=visitor).exists())
        data['related_posts']=PostSerializer(Post.objects.filter(status='PUBLISHED',category=obj.category).exclude(pk=obj.pk)[:3],many=True,context={'request':request}).data
        return Response(data)
    @action(detail=True, methods=['post'], permission_classes=[AllowAny], throttle_classes=[ScopedRateThrottle], throttle_scope='likes')
    def like(self,request,slug=None):
        visitor=request.headers.get('X-Visitor-Id')
        if not visitor: return Response({'detail':'X-Visitor-Id header is required.'},status=400)
        post=self.get_object(); like,created=PostLike.objects.get_or_create(post=post,visitor_id=visitor,defaults={'ip_address':self._ip(request)})
        if not created: like.delete(); liked=False
        else: liked=True
        return Response({'liked':liked,'likes_count':post.likes.count()})
    @action(detail=True, methods=['get','post'], url_path='comments', permission_classes=[AllowAny], throttle_classes=[ScopedRateThrottle], throttle_scope='comments')
    def comments(self,request,slug=None):
        post=self.get_object()
        if request.method=='GET':
            qs=Comment.objects.filter(post=post,is_approved=True,parent__isnull=True).order_by('-created_at')
            def item(c):
                d=CommentSerializer(c).data; d['replies']=CommentSerializer(c.replies.filter(is_approved=True).order_by('created_at'),many=True).data; return d
            return Response([item(c) for c in qs])
        serializer=CommentSerializer(data={**request.data,'post':post.pk})
        serializer.is_valid(raise_exception=True); serializer.save(is_approved=False)
        return Response({'detail':'Your comment is awaiting approval.','comment':serializer.data},status=201)
    @staticmethod
    def _ip(request):
        forwarded=request.META.get('HTTP_X_FORWARDED_FOR')
        return (forwarded.split(',')[0].strip() if forwarded else request.META.get('REMOTE_ADDR')) or None

class ContactViewSet(viewsets.ModelViewSet):
    queryset=ContactMessage.objects.all().order_by('-created_at'); serializer_class=ContactMessageSerializer; permission_classes=[ContactPermission]
    http_method_names=['get','post','patch','delete','head','options']; throttle_classes=[ScopedRateThrottle]; throttle_scope='contact'
    def get_queryset(self):
        if self.request.user.is_authenticated and self.request.user.is_superuser: return super().get_queryset()
        return ContactMessage.objects.none()

class CommentViewSet(viewsets.ModelViewSet):
    queryset=Comment.objects.all().order_by('-created_at'); serializer_class=CommentSerializer; permission_classes=[IsOwnerOrReadOnly]
    def get_queryset(self):
        qs=super().get_queryset()
        if not (self.request.user.is_authenticated and self.request.user.is_superuser): qs=qs.filter(is_approved=True)
        return qs

class DashboardStatsView(APIView):
    permission_classes=[IsAuthenticated]
    def get(self,request):
        if not request.user.is_superuser: return Response({'detail':'Forbidden'},status=403)
        month=timezone.now().date().replace(day=1)
        posts=Post.objects.all()
        top=posts.order_by('-views_count').values('title','slug','views_count')[:5]
        return Response({'total_posts':posts.count(),'published_posts':posts.filter(status='PUBLISHED').count(),'draft_posts':posts.filter(status='DRAFT').count(),'total_projects':Project.objects.count(),'total_skills':Skill.objects.count(),'total_comments':Comment.objects.count(),'pending_comments':Comment.objects.filter(is_approved=False).count(),'total_likes':PostLike.objects.count(),'total_views':posts.aggregate(n=Sum('views_count'))['n'] or 0,'unread_messages':ContactMessage.objects.filter(is_read=False).count(),'top_posts':list(top),'recent_comments':CommentSerializer(Comment.objects.order_by('-created_at')[:5],many=True).data,'posts_per_month':[]})
