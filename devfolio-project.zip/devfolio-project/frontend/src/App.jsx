import {BrowserRouter,Routes,Route} from 'react-router-dom';
import Layout from './components/Layout';
import {Home,Collection,Detail,About,Contact,Login,Dashboard,NotFound} from './pages/Pages';
export default function App(){return <BrowserRouter><Layout><Routes><Route path="/" element={<Home/>}/><Route path="/about" element={<About/>}/><Route path="/projects" element={<Collection type="projects"/>}/><Route path="/projects/:slug" element={<Detail type="projects"/>}/><Route path="/blog" element={<Collection type="blog"/>}/><Route path="/blog/:slug" element={<Detail type="blog"/>}/><Route path="/contact" element={<Contact/>}/><Route path="/login" element={<Login/>}/><Route path="/dashboard" element={<Dashboard/>}/><Route path="*" element={<NotFound/>}/></Routes></Layout></BrowserRouter>}
