import axios from 'axios';
const baseURL=import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000/api';
const api=axios.create({baseURL});
let refreshing=null;
api.interceptors.request.use(config=>{const token=localStorage.getItem('access');if(token)config.headers.Authorization=`Bearer ${token}`;let id=localStorage.getItem('visitor_id');if(!id){id=window.crypto?.randomUUID?.()||`${Date.now()}-${Math.random().toString(36).slice(2)}`;localStorage.setItem('visitor_id',id)}config.headers['X-Visitor-Id']=id;return config});
api.interceptors.response.use(response=>response,async error=>{const original=error.config;if(error.response?.status!==401||!original||original._retry||original.url?.includes('/auth/login/')||original.url?.includes('/auth/refresh/'))return Promise.reject(error);const refresh=localStorage.getItem('refresh');if(!refresh){localStorage.removeItem('access');return Promise.reject(error)}original._retry=true;try{if(!refreshing)refreshing=axios.post(`${baseURL}/auth/refresh/`,{refresh}).finally(()=>{refreshing=null});const result=await refreshing;localStorage.setItem('access',result.data.access);original.headers.Authorization=`Bearer ${result.data.access}`;return api(original)}catch(e){localStorage.removeItem('access');localStorage.removeItem('refresh');if(window.location.pathname!=='/login')window.location.assign('/login');return Promise.reject(e)}});
export default api;
